function trocarImagem (imagem clicada) {
    const imagemDestaque = document.getElementById("imagem-destaque");
    imagemDestaque.src= imagemClicada.src;
}